from rest_framework import generics, status, permissions
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated, IsAdminUser
from django.db.models import Q
from .models import Application
from .serializers import ApplicationSerializer, AdminApplicationSerializer

class ApplicationListCreateView(generics.ListCreateAPIView):
    serializer_class = ApplicationSerializer
    permission_classes = [IsAuthenticated]
    
    def get_queryset(self):
        return Application.objects.filter(user=self.request.user)

class ApplicationDetailView(generics.RetrieveUpdateDestroyAPIView):  # Changed from RetrieveUpdateAPIView
    serializer_class = ApplicationSerializer
    permission_classes = [IsAuthenticated]
    
    def get_queryset(self):
        return Application.objects.filter(user=self.request.user)
    
    def get_serializer(self, *args, **kwargs):
        # For PATCH requests, set partial=True
        if self.request.method == 'PATCH':
            kwargs['partial'] = True
        return super().get_serializer(*args, **kwargs)
    
    def perform_update(self, serializer):
        # Ensure user can only update their own applications
        serializer.save(user=self.request.user)

class AdminApplicationListView(generics.ListAPIView):
    serializer_class = AdminApplicationSerializer
    permission_classes = [IsAdminUser]
    
    def get_queryset(self):
        queryset = Application.objects.all().select_related('user', 'scheme').order_by('-applied_date')
        
        # Filter by status
        status_filter = self.request.query_params.get('status')
        if status_filter:
            queryset = queryset.filter(status=status_filter)
        
        # Filter by scheme type
        scheme_type = self.request.query_params.get('scheme_type')
        if scheme_type:
            queryset = queryset.filter(scheme__scheme_type=scheme_type)
        
        # Search by user or scheme name
        search = self.request.query_params.get('search')
        if search:
            queryset = queryset.filter(
                Q(user__first_name__icontains=search) |
                Q(user__last_name__icontains=search) |
                Q(user__email__icontains=search) |
                Q(scheme__name__icontains=search) |
                Q(application_id__icontains=search)
            )
        
        return queryset

class AdminApplicationUpdateView(generics.RetrieveUpdateAPIView):
    queryset = Application.objects.all()
    serializer_class = AdminApplicationSerializer
    permission_classes = [IsAdminUser]
