from rest_framework import serializers
from .models import Application
from schemes.serializers import SchemeListSerializer
from accounts.serializers import UserProfileSerializer

class ApplicationSerializer(serializers.ModelSerializer):
    scheme = SchemeListSerializer(read_only=True)
    scheme_id = serializers.IntegerField(write_only=True, required=False)
    
    class Meta:
        model = Application
        fields = ('id', 'scheme', 'scheme_id', 'application_id', 'status', 
                 'remarks', 'applied_date', 'last_updated')
        read_only_fields = ('id', 'applied_date', 'last_updated')
        
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        
        # If this is an update operation (instance exists), make certain fields optional
        if self.instance is not None:
            self.fields['scheme_id'].required = False
            self.fields['application_id'].required = False
    
    def create(self, validated_data):
        validated_data['user'] = self.context['request'].user
        return super().create(validated_data)
    
    def update(self, instance, validated_data):
        # Remove scheme_id from validated_data for updates since we can't change it
        validated_data.pop('scheme_id', None)
        return super().update(instance, validated_data)

class AdminApplicationSerializer(serializers.ModelSerializer):
    scheme = SchemeListSerializer(read_only=True)
    user = UserProfileSerializer(read_only=True)
    
    class Meta:
        model = Application
        fields = ('id', 'user', 'scheme', 'application_id', 'status', 
                 'remarks', 'applied_date', 'last_updated')
        read_only_fields = ('id', 'user', 'scheme', 'application_id', 'applied_date', 'last_updated')
        
    def update(self, instance, validated_data):
        # Only allow admin to update status and remarks
        instance.status = validated_data.get('status', instance.status)
        instance.remarks = validated_data.get('remarks', instance.remarks)
        instance.save()
        return instance
