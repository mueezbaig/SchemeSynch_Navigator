from rest_framework import serializers
from .models import Scheme, UserFavorite
from applications.models import Application

class SchemeListSerializer(serializers.ModelSerializer):
    is_favorite = serializers.SerializerMethodField()
    has_applied = serializers.SerializerMethodField()
    
    class Meta:
        model = Scheme
        fields = ('id', 'name', 'description', 'scheme_type', 'category', 'ministry', 
                 'benefits', 'is_active', 'created_at', 'is_favorite', 'has_applied')
    
    def get_is_favorite(self, obj):
        user = self.context.get('request').user if self.context.get('request') else None
        if user and user.is_authenticated:
            return UserFavorite.objects.filter(user=user, scheme=obj).exists()
        return False
    
    def get_has_applied(self, obj):
        user = self.context.get('request').user if self.context.get('request') else None
        if user and user.is_authenticated:
            return Application.objects.filter(user=user, scheme=obj).exists()
        return False

class SchemeDetailSerializer(serializers.ModelSerializer):
    is_favorite = serializers.SerializerMethodField()
    has_applied = serializers.SerializerMethodField()
    application_status = serializers.SerializerMethodField()
    
    class Meta:
        model = Scheme
        fields = '__all__'
    
    def get_is_favorite(self, obj):
        user = self.context.get('request').user if self.context.get('request') else None
        if user and user.is_authenticated:
            return UserFavorite.objects.filter(user=user, scheme=obj).exists()
        return False
    
    def get_has_applied(self, obj):
        user = self.context.get('request').user if self.context.get('request') else None
        if user and user.is_authenticated:
            return Application.objects.filter(user=user, scheme=obj).exists()
        return False
    
    def get_application_status(self, obj):
        user = self.context.get('request').user if self.context.get('request') else None
        if user and user.is_authenticated:
            application = Application.objects.filter(user=user, scheme=obj).first()
            if application:
                return {
                    'status': application.status,
                    'applied_date': application.applied_date,
                    'application_id': application.application_id
                }
        return None

class UserFavoriteSerializer(serializers.ModelSerializer):
    scheme = SchemeListSerializer(read_only=True)
    
    class Meta:
        model = UserFavorite
        fields = ('id', 'scheme', 'added_at')

class SchemeCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Scheme
        fields = '__all__'
        
    def validate_age_min(self, value):
        if value is not None and value < 0:
            raise serializers.ValidationError("Minimum age cannot be negative")
        return value
    
    def validate_age_max(self, value):
        if value is not None and value > 120:
            raise serializers.ValidationError("Maximum age cannot be more than 120")
        return value
    
    def validate(self, attrs):
        age_min = attrs.get('age_min')
        age_max = attrs.get('age_max')
        
        if age_min is not None and age_max is not None and age_min > age_max:
            raise serializers.ValidationError("Minimum age cannot be greater than maximum age")
        
        return attrs
