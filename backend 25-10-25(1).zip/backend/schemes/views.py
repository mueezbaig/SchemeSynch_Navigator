from rest_framework import generics, status, permissions
from rest_framework.decorators import api_view, permission_classes
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated, IsAdminUser
from django.db.models import Q
from .models import Scheme, UserFavorite
from applications.models import Application
from .serializers import SchemeListSerializer, SchemeDetailSerializer, UserFavoriteSerializer, SchemeCreateSerializer

class SchemeListView(generics.ListAPIView):
    serializer_class = SchemeListSerializer
    permission_classes = [IsAuthenticated]
    
    def get_queryset(self):
        user = self.request.user
        
        # Get IDs of schemes user has already applied for
        applied_scheme_ids = Application.objects.filter(user=user).values_list('scheme_id', flat=True)
        
        # Get active schemes excluding the ones user has already applied for
        queryset = Scheme.objects.filter(is_active=True).exclude(id__in=applied_scheme_ids)
        
        # Apply filters
        scheme_type = self.request.query_params.get('scheme_type')
        if scheme_type:
            queryset = queryset.filter(scheme_type=scheme_type)
        
        category = self.request.query_params.get('category')
        if category:
            queryset = queryset.filter(category=category)
        
        search = self.request.query_params.get('search')
        if search:
            queryset = queryset.filter(
                Q(name__icontains=search) |
                Q(description__icontains=search) |
                Q(benefits__icontains=search)
            )
        
        return queryset.order_by('-created_at')

class EligibleSchemesView(generics.ListAPIView):
    serializer_class = SchemeListSerializer
    permission_classes = [IsAuthenticated]
    
    def get_queryset(self):
        user = self.request.user
        
        # Get IDs of schemes user has already applied for
        applied_scheme_ids = Application.objects.filter(user=user).values_list('scheme_id', flat=True)
        
        # Start with active schemes excluding applied ones
        queryset = Scheme.objects.filter(is_active=True).exclude(id__in=applied_scheme_ids)
        
        # Apply eligibility filters based on user profile
        if user.income_group:
            queryset = queryset.filter(
                Q(income_groups__contains=[user.income_group]) |
                Q(income_groups__isnull=True) |
                Q(income_groups=[])
            )
        
        if user.state:
            queryset = queryset.filter(
                Q(applicable_states__contains=[user.state]) |
                Q(applicable_states__isnull=True) |
                Q(applicable_states=[])
            )
        
        if user.age:
            queryset = queryset.filter(
                Q(age_min__isnull=True) | Q(age_min__lte=user.age)
            ).filter(
                Q(age_max__isnull=True) | Q(age_max__gte=user.age)
            )
        
        if user.gender:
            queryset = queryset.filter(
                Q(gender_applicable__contains=[user.gender]) |
                Q(gender_applicable__isnull=True) |
                Q(gender_applicable=[])
            )
        
        return queryset.order_by('-created_at')

class SchemeDetailView(generics.RetrieveAPIView):
    serializer_class = SchemeDetailSerializer
    permission_classes = [IsAuthenticated]
    
    def get_queryset(self):
        return Scheme.objects.filter(is_active=True)
    
    def get_serializer_context(self):
        context = super().get_serializer_context()
        context['user'] = self.request.user
        return context

@api_view(['POST', 'DELETE'])
@permission_classes([IsAuthenticated])
def toggle_favorite(request, scheme_id):
    try:
        scheme = Scheme.objects.get(id=scheme_id, is_active=True)
    except Scheme.DoesNotExist:
        return Response({'error': 'Scheme not found'}, status=status.HTTP_404_NOT_FOUND)
    
    favorite, created = UserFavorite.objects.get_or_create(
        user=request.user,
        scheme=scheme
    )
    
    if request.method == 'DELETE' or not created:
        favorite.delete()
        return Response({'message': 'Removed from favorites'})
    else:
        return Response({'message': 'Added to favorites'})

class UserFavoritesView(generics.ListAPIView):
    serializer_class = UserFavoriteSerializer
    permission_classes = [IsAuthenticated]
    
    def get_queryset(self):
        user = self.request.user
        
        # Get user's favorites where the scheme is still active and not applied
        applied_scheme_ids = Application.objects.filter(user=user).values_list('scheme_id', flat=True)
        
        return UserFavorite.objects.filter(
            user=user,
            scheme__is_active=True
        ).exclude(scheme_id__in=applied_scheme_ids).order_by('-added_at')

# Admin views remain the same...
class AdminSchemeListView(generics.ListAPIView):
    queryset = Scheme.objects.all()
    serializer_class = SchemeDetailSerializer
    permission_classes = [IsAuthenticated]
    
    def get_queryset(self):
        if not (self.request.user.is_staff or self.request.user.is_superuser):
            return Scheme.objects.none()
            
        queryset = Scheme.objects.all().order_by('-created_at')
        
        is_active = self.request.query_params.get('is_active')
        if is_active is not None:
            queryset = queryset.filter(is_active=is_active.lower() == 'true')
            
        search = self.request.query_params.get('search')
        if search:
            queryset = queryset.filter(
                Q(name__icontains=search) |
                Q(description__icontains=search) |
                Q(ministry__icontains=search)
            )
        
        return queryset

class SchemeCreateView(generics.CreateAPIView):
    serializer_class = SchemeCreateSerializer
    permission_classes = [IsAuthenticated]
    
    def perform_create(self, serializer):
        if not (self.request.user.is_staff or self.request.user.is_superuser):
            raise permissions.PermissionDenied("Admin privileges required")
        serializer.save()

class SchemeUpdateView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Scheme.objects.all()
    serializer_class = SchemeCreateSerializer
    permission_classes = [IsAuthenticated]
    
    def get_object(self):
        if not (self.request.user.is_staff or self.request.user.is_superuser):
            raise permissions.PermissionDenied("Admin privileges required")
        return super().get_object()
    
    def perform_update(self, serializer):
        if not (self.request.user.is_staff or self.request.user.is_superuser):
            raise permissions.PermissionDenied("Admin privileges required")
        serializer.save()
    
    def perform_destroy(self, instance):
        if not (self.request.user.is_staff or self.request.user.is_superuser):
            raise permissions.PermissionDenied("Admin privileges required")
        instance.delete()
